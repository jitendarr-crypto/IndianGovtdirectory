-- ============================================================
-- Seed: additional states referenced by MPs (Lok Sabha electorates)
-- Uses ON CONFLICT so this is safe even if some already exist.
-- ============================================================

insert into states (id, name, level, assembly_name, source_url) values
  ('uttar_pradesh', 'Uttar Pradesh', 'state', NULL, NULL),
  ('maharashtra', 'Maharashtra', 'state', NULL, NULL),
  ('west_bengal', 'West Bengal', 'state', NULL, NULL),
  ('bihar', 'Bihar', 'state', NULL, NULL),
  ('tamil_nadu', 'Tamil Nadu', 'state', NULL, NULL),
  ('madhya_pradesh', 'Madhya Pradesh', 'state', NULL, NULL),
  ('karnataka', 'Karnataka', 'state', NULL, NULL),
  ('gujarat', 'Gujarat', 'state', NULL, NULL),
  ('rajasthan', 'Rajasthan', 'state', NULL, NULL),
  ('andhra_pradesh', 'Andhra Pradesh', 'state', NULL, NULL),
  ('odisha', 'Odisha', 'state', NULL, NULL),
  ('kerala', 'Kerala', 'state', NULL, NULL),
  ('telangana', 'Telangana', 'state', NULL, NULL),
  ('assam', 'Assam', 'state', NULL, NULL),
  ('jharkhand', 'Jharkhand', 'state', NULL, NULL),
  ('punjab', 'Punjab', 'state', NULL, NULL),
  ('chhattisgarh', 'Chhattisgarh', 'state', NULL, NULL),
  ('haryana', 'Haryana', 'state', NULL, NULL),
  ('delhi', 'Delhi', 'state', NULL, NULL),
  ('jammu_kashmir', 'Jammu and Kashmir', 'state', NULL, NULL),
  ('uttarakhand', 'Uttarakhand', 'state', NULL, NULL),
  ('himachal_pradesh', 'Himachal Pradesh', 'state', NULL, NULL),
  ('arunachal_pradesh', 'Arunachal Pradesh', 'state', NULL, NULL),
  ('goa', 'Goa', 'state', NULL, NULL),
  ('tripura', 'Tripura', 'state', NULL, NULL),
  ('meghalaya', 'Meghalaya', 'state', NULL, NULL),
  ('manipur', 'Manipur', 'state', NULL, NULL),
  ('nagaland', 'Nagaland', 'state', NULL, NULL),
  ('mizoram', 'Mizoram', 'state', NULL, NULL),
  ('sikkim', 'Sikkim', 'state', NULL, NULL),
  ('andaman_nicobar_islands', 'Andaman and Nicobar Islands', 'state', NULL, NULL),
  ('chandigarh', 'Chandigarh', 'state', NULL, NULL),
  ('dadra_nagar_haveli_daman_diu', 'Dadra and Nagar Haveli and Daman and Diu', 'state', NULL, NULL),
  ('ladakh', 'Ladakh', 'state', NULL, NULL),
  ('lakshadweep', 'Lakshadweep', 'state', NULL, NULL),
  ('puducherry', 'Puducherry', 'state', NULL, NULL)
on conflict (id) do nothing;
