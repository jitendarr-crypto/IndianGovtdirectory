-- ============================================================
-- Seed: officials — Maharashtra
-- ============================================================

insert into officials (state_id, role_type, role_title, name, seat, note, source_url, last_checked, confidence, display_order) values
  ('maharashtra', 'chief', 'Chief Minister of Maharashtra', 'Devendra Fadnavis', NULL, 'Bharatiya Janata Party; Nagpur South West constituency; Leader of the House; holds Home, General Administration, and other unallocated portfolios. Deputy CMs: Eknath Shinde (Shiv Sena) and Sunetra Pawar (NCP, since 2026, following Ajit Pawar''s death in a plane crash 28 Jan 2026)', 'https://en.wikipedia.org/wiki/15th_Maharashtra_Assembly', '2026-08-23', 'high', 0),
  ('maharashtra', 'minister', 'Deputy Chief Minister', 'Eknath Shinde', 'Kopri-Pachpakhadi', NULL, 'https://www.myneta.info/Maharashtra2024/index.php?action=show_winners&sort=default', '2026-08-23', 'high', 1),
  ('maharashtra', 'minister', 'Deputy Chief Minister (NCP); took over after Ajit Pawar''s death Jan 2026', 'Sunetra Pawar', 'MLC', NULL, 'https://www.myneta.info/Maharashtra2024/index.php?action=show_winners&sort=default', '2026-08-23', 'medium', 2),
  ('maharashtra', 'minister', 'Revenue', 'Chandrashekhar Bawankule', 'Kamthi', NULL, 'https://www.myneta.info/Maharashtra2024/index.php?action=show_winners&sort=default', '2026-08-23', 'high', 3),
  ('maharashtra', 'minister', 'Rural Development', 'Girish Mahajan', 'Jamner', NULL, 'https://www.myneta.info/Maharashtra2024/index.php?action=show_winners&sort=default', '2026-08-23', 'high', 4),
  ('maharashtra', 'minister', 'Water Resources', 'Radhakrishna Vikhe Patil', 'Shirdi', NULL, 'https://www.myneta.info/Maharashtra2024/index.php?action=show_winners&sort=default', '2026-08-23', 'high', 5),
  ('maharashtra', 'minister', 'Industries', 'Uday Samant', 'Ratnagiri', NULL, 'https://www.myneta.info/Maharashtra2024/index.php?action=show_winners&sort=default', '2026-08-23', 'high', 6),
  ('maharashtra', 'minister', 'Forest, Cultural Affairs & Fisheries', 'Sudhir Mungantiwar', 'Ballarpur', NULL, 'https://www.myneta.info/Maharashtra2024/index.php?action=show_winners&sort=default', '2026-08-23', 'high', 7),
  ('maharashtra', 'minister', 'Cabinet Minister', 'Dhananjay Munde', 'Parli', NULL, 'https://www.myneta.info/Maharashtra2024/index.php?action=show_winners&sort=default', '2026-08-23', 'medium', 8),
  ('maharashtra', 'minister', 'School Education', 'Deepak Kesarkar', 'Sawantwadi', NULL, 'https://www.myneta.info/Maharashtra2024/index.php?action=show_winners&sort=default', '2026-08-23', 'high', 9),
  ('maharashtra', 'minister', 'Skill Development & Tourism', 'Mangal Prabhat Lodha', 'Malabar Hill', NULL, 'https://www.myneta.info/Maharashtra2024/index.php?action=show_winners&sort=default', '2026-08-23', 'high', 10),
  ('maharashtra', 'minister', 'Fisheries & Ports', 'Nitesh Rane', 'Kankavli', NULL, 'https://www.myneta.info/Maharashtra2024/index.php?action=show_winners&sort=default', '2026-08-23', 'high', 11);
