-- ============================================================
-- Seed: Tamil Nadu in states (idempotent)
-- ============================================================

insert into states (id, name, level, assembly_name, source_url) values
  ('tamil_nadu', 'Tamil Nadu', 'state', '17th Tamil Nadu Legislative Assembly (2026–2031)', 'https://www.findeasy.in/constituencies-in-tamil-nadu-legislative-assembly/')
on conflict (id) do update set assembly_name = excluded.assembly_name;
