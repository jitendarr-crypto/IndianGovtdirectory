-- ============================================================
-- Seed: officials — Tamil Nadu
-- ============================================================

insert into officials (state_id, role_type, role_title, name, seat, note, source_url, last_checked, confidence, display_order) values
  ('tamil_nadu', 'chief', 'Chief Minister of Tamil Nadu', 'C. Joseph Vijay', NULL, 'Tamilaga Vettri Kazhagam (TVK); Perambur constituency; first Chief Minister outside the DMK-AIADMK duopoly in 59 years, sworn in 10 May 2026 after a hung assembly; TVK is the largest party (108 of 234 seats) governing with INC, IUML, CPI, VCK, CPIM and defector support; won floor test 144-22 on 13 May 2026', 'https://tnmla.in/', '2026-08-23', 'high', 0),
  ('tamil_nadu', 'minister', 'Finance, Planning & Development', 'N. Marie Wilson', 'Dr. Radhakrishnan Nagar', NULL, 'https://tnmla.in/', '2026-08-23', 'high', 1),
  ('tamil_nadu', 'minister', 'Leader of the House; Revenue & Disaster Management', 'K. A. Sengottaiyan', 'Gobichettipalayam', NULL, 'https://tnmla.in/', '2026-08-23', 'high', 2),
  ('tamil_nadu', 'minister', 'Rural Development & Water Resources', 'N. Anand', 'Thiyagaraya Nagar', NULL, 'https://tnmla.in/', '2026-08-23', 'high', 3),
  ('tamil_nadu', 'minister', 'Health & Family Welfare', 'Dr. K. G. Arunraj', 'Tiruchengodu', NULL, 'https://tnmla.in/', '2026-08-23', 'high', 4),
  ('tamil_nadu', 'minister', 'HR Management', 'D. Sarathkumar', 'Tambaram', NULL, 'https://tnmla.in/', '2026-08-23', 'high', 5),
  ('tamil_nadu', 'minister', 'Social Welfare', 'K. Jegadeshwari', 'Rajapalayam', NULL, 'https://tnmla.in/', '2026-08-23', 'high', 6),
  ('tamil_nadu', 'minister', 'Minorities Welfare & Wakf', 'A. M. Shahjahan', 'Papanasam', NULL, 'https://tnmla.in/', '2026-08-23', 'high', 7),
  ('tamil_nadu', 'minister', 'Social Justice, Adi Dravidar & Hill Tribes Welfare', 'Vanni Arasu', 'Tindivanam', NULL, 'https://tnmla.in/', '2026-08-23', 'high', 8),
  ('tamil_nadu', 'minister', 'Energy & Law', 'R. Nirmalkumar', 'Thiruparankundram', NULL, 'https://tnmla.in/', '2026-08-23', 'high', 9),
  ('tamil_nadu', 'minister', 'Agriculture', 'Vinoth', 'Kumbakonam', NULL, 'https://tnmla.in/', '2026-08-23', 'high', 10),
  ('tamil_nadu', 'minister', 'Housing & Urban Development', 'B. Rajkumar', 'Cuddalore', NULL, 'https://tnmla.in/', '2026-08-23', 'high', 11);
