-- ============================================================
-- Seed: officials — Uttar Pradesh
-- ============================================================

insert into officials (state_id, role_type, role_title, name, seat, note, source_url, last_checked, confidence, display_order) values
  ('uttar_pradesh', 'chief', 'Chief Minister of Uttar Pradesh', 'Yogi Adityanath', NULL, 'Bharatiya Janata Party; Gorakhpur Urban constituency; holds Home, Vigilance, Revenue, General Administration, Institutional Finance, Civil Aviation, Law & Legislative, and other unallocated portfolios', 'https://en.wikipedia.org/wiki/18th_Uttar_Pradesh_Assembly', '2026-08-23', 'high', 0),
  ('uttar_pradesh', 'minister', 'Deputy CM; Rural Development, Rural Engineering Services, Food Processing', 'Keshav Prasad Maurya', 'MLC (Legislative Council)', NULL, 'https://en.wikipedia.org/wiki/18th_Uttar_Pradesh_Assembly', '2026-08-23', 'high', 1),
  ('uttar_pradesh', 'minister', 'Deputy CM; Medical Education, Medical & Health, Family Welfare', 'Brajesh Pathak', 'Lucknow Cantonment', NULL, 'https://en.wikipedia.org/wiki/18th_Uttar_Pradesh_Assembly', '2026-08-23', 'high', 2),
  ('uttar_pradesh', 'minister', 'Finance; Parliamentary Affairs', 'Suresh Kumar Khanna', 'Shahjahanpur', NULL, 'https://en.wikipedia.org/wiki/18th_Uttar_Pradesh_Assembly', '2026-08-23', 'high', 3),
  ('uttar_pradesh', 'minister', 'Agriculture; Agricultural Education & Research', 'Surya Pratap Shahi', 'Pathardeva', NULL, 'https://en.wikipedia.org/wiki/18th_Uttar_Pradesh_Assembly', '2026-08-23', 'high', 4),
  ('uttar_pradesh', 'minister', 'Women & Child Development', 'Baby Rani Maurya', 'Agra Rural', NULL, 'https://en.wikipedia.org/wiki/18th_Uttar_Pradesh_Assembly', '2026-08-23', 'high', 5),
  ('uttar_pradesh', 'minister', 'Sugarcane Development & Sugar Mills', 'Chaudhary Laxmi Narayan Singh', 'Chhata', NULL, 'https://en.wikipedia.org/wiki/18th_Uttar_Pradesh_Assembly', '2026-08-23', 'high', 6),
  ('uttar_pradesh', 'minister', 'Tourism & Culture', 'Jaiveer Singh', 'Mainpuri', NULL, 'https://en.wikipedia.org/wiki/18th_Uttar_Pradesh_Assembly', '2026-08-23', 'high', 7),
  ('uttar_pradesh', 'minister', 'Animal Husbandry & Dairy Development; Minority Welfare, Haj & Waqf', 'Dharmpal Singh', 'Aonla', NULL, 'https://en.wikipedia.org/wiki/18th_Uttar_Pradesh_Assembly', '2026-08-23', 'high', 8),
  ('uttar_pradesh', 'minister', 'Industrial Development, Export Promotion, NRI & Investment Promotion', 'Nand Gopal Gupta ''Nandi''', 'Prayagraj South', NULL, 'https://en.wikipedia.org/wiki/18th_Uttar_Pradesh_Assembly', '2026-08-23', 'high', 9),
  ('uttar_pradesh', 'minister', 'Cabinet Minister', 'Rakesh Sachan', 'Bhognipur', NULL, 'https://en.wikipedia.org/wiki/18th_Uttar_Pradesh_Assembly', '2026-08-23', 'medium', 10),
  ('uttar_pradesh', 'minister', 'Cabinet Minister', 'Anil Rajbhar', 'Shivpur', NULL, 'https://en.wikipedia.org/wiki/18th_Uttar_Pradesh_Assembly', '2026-08-23', 'medium', 11);
