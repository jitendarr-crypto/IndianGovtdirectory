-- ============================================================
-- Seed: Bihar in states (idempotent)
-- ============================================================

insert into states (id, name, level, assembly_name, source_url) values
  ('bihar', 'Bihar', 'state', '18th Bihar Legislative Assembly (2025–2030)', 'https://www.findeasy.in/constituencies-in-bihar-legislative-assembly/')
on conflict (id) do update set assembly_name = excluded.assembly_name;
