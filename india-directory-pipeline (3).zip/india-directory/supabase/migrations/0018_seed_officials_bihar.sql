-- ============================================================
-- Seed: officials — Bihar
-- ============================================================

insert into officials (state_id, role_type, role_title, name, seat, note, source_url, last_checked, confidence, display_order) values
  ('bihar', 'chief', 'Chief Minister of Bihar', 'Samrat Choudhary', NULL, 'Bharatiya Janata Party; Tarapur constituency; 24th CM, first from BJP in Bihar''s history; sworn in 15 Apr 2026 succeeding Nitish Kumar, who resigned after election to the Rajya Sabha; holds Home, Vigilance, Health, Industries and other unallocated portfolios', 'https://en.wikipedia.org/wiki/Samrat_Choudhary', '2026-08-23', 'high', 0),
  ('bihar', 'minister', 'Deputy CM; Education, Transport, Water Resources', 'Vijay Kumar Chaudhary', 'Sarairanjan', NULL, 'https://en.wikipedia.org/wiki/Samrat_Choudhary', '2026-08-23', 'high', 1),
  ('bihar', 'minister', 'Deputy CM; Finance, Energy, Commercial Taxes', 'Bijendra Prasad Yadav', 'Supaul', NULL, 'https://en.wikipedia.org/wiki/Samrat_Choudhary', '2026-08-23', 'high', 2),
  ('bihar', 'minister', 'Agriculture', 'Vijay Kumar Sinha', 'Lakhisarai', NULL, 'https://en.wikipedia.org/wiki/Samrat_Choudhary', '2026-08-23', 'high', 3),
  ('bihar', 'minister', 'Rural Development; Information & Public Relations', 'Shrawan Kumar', 'Nalanda', NULL, 'https://en.wikipedia.org/wiki/Samrat_Choudhary', '2026-08-23', 'high', 4),
  ('bihar', 'minister', 'Building Construction', 'Leshi Singh', 'Dhamdaha', NULL, 'https://en.wikipedia.org/wiki/Samrat_Choudhary', '2026-08-23', 'high', 5),
  ('bihar', 'minister', 'Revenue & Land Reforms', 'Dilip Kumar Jaiswal', 'MLC (Legislative Council)', NULL, 'https://en.wikipedia.org/wiki/Samrat_Choudhary', '2026-08-23', 'high', 6),
  ('bihar', 'minister', 'Food & Consumer Protection', 'Ashok Choudhary', 'MLC (Legislative Council)', NULL, 'https://en.wikipedia.org/wiki/Samrat_Choudhary', '2026-08-23', 'high', 7),
  ('bihar', 'minister', 'Minor Water Resources', 'Santosh Kumar Suman', 'MLC (Legislative Council)', NULL, 'https://en.wikipedia.org/wiki/Samrat_Choudhary', '2026-08-23', 'high', 8);
