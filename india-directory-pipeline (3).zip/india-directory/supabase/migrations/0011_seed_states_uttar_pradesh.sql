-- ============================================================
-- Seed: Uttar Pradesh in states (idempotent -- may already exist from mps-pending seed)
-- ============================================================

insert into states (id, name, level, assembly_name, source_url) values
  ('uttar_pradesh', 'Uttar Pradesh', 'state', '18th Uttar Pradesh Legislative Assembly (2022–2027)', 'https://en.wikipedia.org/wiki/18th_Uttar_Pradesh_Assembly')
on conflict (id) do update set assembly_name = excluded.assembly_name;
