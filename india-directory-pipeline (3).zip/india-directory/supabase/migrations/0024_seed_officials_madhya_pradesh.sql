-- ============================================================
-- Seed: officials — Madhya Pradesh
-- ============================================================

insert into officials (state_id, role_type, role_title, name, seat, note, source_url, last_checked, confidence, display_order) values
  ('madhya_pradesh', 'chief', 'Chief Minister of Madhya Pradesh', 'Mohan Yadav', NULL, 'Bharatiya Janata Party; Ujjain South constituency; sworn in December 2023', 'https://en.wikipedia.org/wiki/16th_Madhya_Pradesh_Assembly', '2026-08-23', 'high', 0),
  ('madhya_pradesh', 'minister', 'Deputy Chief Minister', 'Jagdish Devda', 'Malhargarh', NULL, 'https://en.wikipedia.org/wiki/16th_Madhya_Pradesh_Assembly', '2026-08-23', 'high', 1),
  ('madhya_pradesh', 'minister', 'Deputy Chief Minister', 'Rajendra Shukla', 'Rewa', NULL, 'https://en.wikipedia.org/wiki/16th_Madhya_Pradesh_Assembly', '2026-08-23', 'high', 2),
  ('madhya_pradesh', 'minister', 'Urban Development & Housing', 'Kailash Vijayvargiya', 'Indore-1', NULL, 'https://en.wikipedia.org/wiki/16th_Madhya_Pradesh_Assembly', '2026-08-23', 'medium', 3),
  ('madhya_pradesh', 'minister', 'Health & Family Welfare', 'Vishvas Sarang', 'Narela', NULL, 'https://en.wikipedia.org/wiki/16th_Madhya_Pradesh_Assembly', '2026-08-23', 'medium', 4),
  ('madhya_pradesh', 'minister', 'Cabinet Minister', 'Tulsi Silawat', 'Sanwer', NULL, 'https://en.wikipedia.org/wiki/16th_Madhya_Pradesh_Assembly', '2026-08-23', 'medium', 5),
  ('madhya_pradesh', 'minister', 'Panchayat & Rural Development', 'Prahlad Singh Patel', 'Narsingpur', NULL, 'https://en.wikipedia.org/wiki/16th_Madhya_Pradesh_Assembly', '2026-08-23', 'medium', 6),
  ('madhya_pradesh', 'minister', 'Cabinet Minister', 'Govind Singh Rajput', 'Surkhi', NULL, 'https://en.wikipedia.org/wiki/16th_Madhya_Pradesh_Assembly', '2026-08-23', 'medium', 7),
  ('madhya_pradesh', 'minister', 'Cabinet Minister', 'Rameshwar Sharma', 'Huzur', NULL, 'https://en.wikipedia.org/wiki/16th_Madhya_Pradesh_Assembly', '2026-08-23', 'medium', 8),
  ('madhya_pradesh', 'minister', 'Cabinet Minister', 'Bhupendra Singh', 'Khurai', NULL, 'https://en.wikipedia.org/wiki/16th_Madhya_Pradesh_Assembly', '2026-08-23', 'medium', 9);
