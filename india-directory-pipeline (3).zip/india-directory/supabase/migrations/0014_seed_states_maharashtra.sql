-- ============================================================
-- Seed: Maharashtra in states (idempotent)
-- ============================================================

insert into states (id, name, level, assembly_name, source_url) values
  ('maharashtra', 'Maharashtra', 'state', '15th Maharashtra Legislative Assembly (2024–2029)', 'https://www.findeasy.in/constituencies-in-maharashtra-legislative-assembly/')
on conflict (id) do update set assembly_name = excluded.assembly_name;
