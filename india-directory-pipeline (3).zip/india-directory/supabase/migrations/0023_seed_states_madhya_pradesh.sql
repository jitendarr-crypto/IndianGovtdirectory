-- ============================================================
-- Seed: Madhya Pradesh in states (idempotent)
-- ============================================================

insert into states (id, name, level, assembly_name, source_url) values
  ('madhya_pradesh', 'Madhya Pradesh', 'state', '16th Madhya Pradesh Legislative Assembly (2023–2028)', 'https://en.wikipedia.org/wiki/16th_Madhya_Pradesh_Assembly')
on conflict (id) do update set assembly_name = excluded.assembly_name;
